# psqli-pro
Powerfull Automatic Sql injection Tools Pack
<h1 align="center">
  <img src="https://i.ibb.co/LYnKqpr/logopsqli.png"></h1>
   <h2 align="center">Fast Automatic Sql injection, SQLi Dumper<br>URL Fuzzer, Dork Tools & cracking tools
<p align="center">
  </a>
  <a href="psqli.sh">
     <img src="https://i.ibb.co/br5DH3z/1586858881-picsay.jpg" height="30" width="210">
  </a>
</h2>
</p>
<p align="center">
  <img src="https://i.ibb.co/JjGDcgw/psqli2.png">
</p>

### Fitur
<li> singgle site injection
<li> Mass Xploit sql-injection
<li> aUTO DorKiNg + AutO Xploit
<li> SQLi Base64 injection
<li> SQLi POST method
<li> SQLi ERROR Based method
<li> scan site + auto inject ( web crawler )
<li> Reverse ip vuln sqli + auto inject
<li> Query Email Pass dumper + auto filter mail
<li> Hash tools
<li> Dork generator
<li> New Admin Finder
<li> Psqli Sqli/Xss/LFI/AdminFinder Scanner
  
### NEW Pro feature
<li> SQLi dork auto dumper + auto filter email;pass
<li> Auto Bypass SQL Login
<li> Dork generator
<li> Coming soon SQL into out file
  
### Methode injection
<li> Union based method
<li> Error based method
  
#### Di lengkapi
<li> auto detect vuln
<li> order by bisa di sesuaikan
<li> auto detect string based
<li> new bypassing waf query
<li> multiple injection method
<li> auto filtering table
<li> auto correct input db dan table
<li> local variabel method
<li> tertanam 6 dios racikan master sqli
<li> auto filter email::password
<li> auto scaning dorking
<li> skip prosess dengan ctrl+c atau ctrl+d
<li> query bisa di edit sesuai selera
<li> html injection
<li> base64 injection
<li> double query injection
<li> post method injection
<li> mencari login page dengan 2 method
<li> fast URL scraping atau crawler
<li> auto dorking edit lahh bagian .sites dan .key untuk mendapatkan hasil yang memuaskan
<li> mudahh edit input output di bagian atas script
<li> Dan masih banyak lagi
  
### Fix error inject site
<li> https://www.prettypetalsstore.com/single.php?id=68
<li> https://www.smkdarulmuqomah.id/statis-16-program-keahlian.html
<li> https://www.sedimental.com/catalog/index.php?ID=80
<li> http://sekarlaut.com/products.php?ID=23&cID=1
<li> http://lexsite.com/latestArticle.php?id=5
<li> http://gandariacity.co.id/tenant.php?id=17
<li> http://tf.lan.go.id/statis-1-profil.html
<li> http://www.godmother.co.uk/single-blog.php?blog_id=66
  
### Instalasi
  ```bash
$ pkg install bash curl git
$ git clone https://github.com/Agressiv1njector/psqli-pro
$ cd psqli-pro
$ bash psqli.sh
$ bash psqli.sh s #untuk string based injection only

psqli* is licensed under [GPL v3.0 license](https://www.gnu.org/licenses/gpl-3.0.en.html)
